package kz.bitlab.group21boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group21bootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Group21bootApplication.class, args);
	}

}
